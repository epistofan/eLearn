package lv.elearning.elearningProject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ElearningProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(ElearningProjectApplication.class, args);
	}

}
